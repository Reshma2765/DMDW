# DMWD_LAB
Data mining and data warehouse lab (5th sem)
